AERONAUT 747-8 corresponding source (GPL-2.0-only)

See LICENSE.txt, UPSTREAM-AUTHORS.txt and MODIFICATIONS.txt.
Native source: JMaverick16/747-8 commit 0ed6056990828084bd51770e3ad73d0b61a1ad61.
The engine/gear/tyre image files referenced by native AC3D are not needed:
textures.py creates original neutral replacements. No unverified original engine
photo or GE logo is included. Fuselage/wing images retain upstream GPL terms.

Requires Blender 4.3.2 (bundled NumPy) and Node.js >=22.
Run from this directory:
blender -b --python scripts/convert.py -- Models build/high 2
blender -b --python scripts/convert.py -- Models build/balanced 1
npm install @gltf-transform/core@4.2.1 @gltf-transform/extensions@4.5.1 @gltf-transform/functions@4.2.1 meshoptimizer@0.22.0 sharp@0.35.5 gltf-validator@2.0.0-dev.3.10
mkdir -p docs/three-explorer/boeing747
node scripts/optimize.mjs build/high build/balanced

These steps regenerate GLBs, texture atlases, editable intermediate BLEND files
and renders. Meshopt/quantization decoders are local, not CDN-dependent.
No triangle padding or duplicated airframes are used. CPU render images do not
establish GPU FPS. The website source repository contains the separate runtime,
Three.js viewer, tests and integration instructions.
